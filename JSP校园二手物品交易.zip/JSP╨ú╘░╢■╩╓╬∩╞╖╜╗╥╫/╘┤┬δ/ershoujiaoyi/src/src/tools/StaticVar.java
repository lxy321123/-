package src.tools;

public class StaticVar {
	//这里放一些网站配置数据
	public static int PERPAGE_MESS=10;//消息页每页显示个数
	public static int PERPAGE_GOODS=11;//物品浏览页每页显示个数
	public static int PERPAGE_COLLECT=7;//收藏页每页显示个数
	public static boolean USESQLPOOL=false;//是否使用连接池
}
