package src.dbc;
import java.sql.*;
public class DatabaseConnection {
	private static final String DBDRIVER = "com.mysql.jdbc.Driver" ; 
	private static final String DBURL = "jdbc:mysql://47.101.198.61:3306/jsp_ershoujiaoyi" ;
	private static final String DBUSER = "jsp_ershoujiaoyi" ;
	private static final String DBPASSWORD = "jsp_ershoujiaoyi" ;
	private Connection conn ;
	public DatabaseConnection() throws Exception {
		Class.forName(DBDRIVER) ;
		this.conn = DriverManager.getConnection(DBURL,DBUSER,DBPASSWORD) ;
		//this.conn.createStatement().execute("SET NAMES utf8");
	}
	public Connection getConnection(){
		return this.conn ;
	}
	public void close() throws Exception {
		if(this.conn != null){
			try{
				this.conn.close() ;
			}catch(Exception e){
				throw e ;
			}
		}
	}
}
